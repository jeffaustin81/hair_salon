-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 22, 2015 at 01:55 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hair_salon`
--
CREATE DATABASE IF NOT EXISTS `hair_salon` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `hair_salon`;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `client_name` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `stylist_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`client_name`, `id`, `email`, `stylist_id`) VALUES
('lsakjfdlk', 1, 'kldsjafl', 3),
('Jeff Austin', 2, 'jeffaustin81@gmail.com', 7),
('Jeff Austin', 3, 'jeffaustin81@gmail.com', 8),
('Jackie Git', 4, 'jackie@gmail.com', 8),
('Jeff Austin', 5, 'jeffaustin81@gmail.com', 12),
('Jeff Austin', 6, 'jeffaustin81@gmail.com', 12),
('Jeff Austin', 7, 'jeffaustin81@gmail.com', 14),
('Jeff Jeff', 8, 'jeffaustin81@gmail.com', 17),
('Jeff Austin', 9, 'jeffaustin81@gmail.com', 18),
('Billy Drupal', 10, 'billydrupal45@gmail.com', 18),
('Jill Benson', 11, 'jillbenson6@gmail.com', 18),
('Jim Beam', 12, 'jimbeam34@gmail.com', 19),
('Jack Daniels', 13, 'jackdaniels@gmail.com', 19),
('Kelly Tims', 14, 'kellytims@gmail.com', 19),
('Elizabeth Wells', 15, 'lizzywells@yahoo.com', 20),
('Lila Sims', 16, 'lilasims@outlook.com', 20),
('Rita Jackson', 17, 'ritajackson34@gmail.com', 20);

-- --------------------------------------------------------

--
-- Table structure for table `stylists`
--

CREATE TABLE `stylists` (
  `stylist_name` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stylists`
--

INSERT INTO `stylists` (`stylist_name`, `id`) VALUES
('Jackie Burns', 18),
('Ronda Kelly', 19),
('Jill Keys', 20),
('Tim Jackson', 21),
('Jon Watson', 22);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stylists`
--
ALTER TABLE `stylists`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `stylists`
--
ALTER TABLE `stylists`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
